import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://textbin.net/qn6t41z3jd'

'''#####-----Notifications File-----#####'''
notify_url  = ''

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.mbwizard']
