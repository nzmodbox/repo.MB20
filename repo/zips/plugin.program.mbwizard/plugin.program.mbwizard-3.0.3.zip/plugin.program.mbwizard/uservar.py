import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://nzmodbox.github.io/nzmodbox.com/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://nzmodbox.github.io/nzmodbox.com/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.Program.mbwizard']
